# Kubuntu Website Archive

The original website (pre LTS 24.04) was driven using WordPress. This directory [archives/] contains a static mirror of that site and it's content
It is linked into the current site via the archives link in the page footer.


